package http://fhir-registry.smarthealthit.org/ImplementationGuide/ig;

import org.hl7.fhir.r4.model.ProfilingWrapper;

public class SupportForDicoveryOfOAuth2Endpoints {

}
